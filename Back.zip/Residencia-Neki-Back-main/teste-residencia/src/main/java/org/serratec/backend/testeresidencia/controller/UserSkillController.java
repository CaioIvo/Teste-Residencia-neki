package org.serratec.backend.testeresidencia.controller;

import java.util.List;

import org.serratec.backend.testeresidencia.dto.ListagemSkillsDTO;
import org.serratec.backend.testeresidencia.dto.UserSkillDTO;
import org.serratec.backend.testeresidencia.service.UserSkillService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/user-skill")
public class UserSkillController {

	@Autowired
	private UserSkillService userskillService;
	
	@PostMapping("/save")
	public ResponseEntity<Void> salvar(@RequestBody UserSkillDTO dto){
		userskillService.associarSkill(dto);
		return new ResponseEntity<Void>(HttpStatus.CREATED);
	}
	
	@PutMapping("/atualizar")
	public ResponseEntity<Void> atualizar(@RequestParam Long idUserSkill, @RequestBody UserSkillDTO dto){
		userskillService.atualizarSkill(idUserSkill,dto);
		return new ResponseEntity<Void>(HttpStatus.ACCEPTED);
	}
	
	@DeleteMapping("/{idUserSkill}")
	public ResponseEntity<Void> delete(@PathVariable Long idUserSkill){
		userskillService.deleteSkill(idUserSkill);
		return new ResponseEntity<Void>(HttpStatus.ACCEPTED);
	}
	
	@GetMapping("/lista")
	public ResponseEntity<List<UserSkillDTO>> lista(){
		return ResponseEntity.ok(userskillService.listaUserSkill());
	}
	
	@GetMapping("/lista-skill-usuario/{idUsuario}")
	public ResponseEntity<ListagemSkillsDTO> listaSkillUsuario(@PathVariable Long idUsuario){
		return ResponseEntity.ok(userskillService.listaSkillPorUsuario(idUsuario));
	}
	
}
