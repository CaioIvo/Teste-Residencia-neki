package org.serratec.backend.testeresidencia.service;

import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import org.modelmapper.ModelMapper;
import org.serratec.backend.testeresidencia.domain.Usuario;
import org.serratec.backend.testeresidencia.dto.UsuarioDTO;
import org.serratec.backend.testeresidencia.exception.BadRequestException;
import org.serratec.backend.testeresidencia.repository.UsuarioRepository;
import org.springframework.beans.factory.annotation.Autowired;


@Service
public class UsuarioService {

    @Autowired
    private UsuarioRepository usuarioRepository;

    @Autowired
	ModelMapper mapper;

    /**
     * Método que retorna uma Lista de usuarios
     * @return Lista de usuario
     */
    public List<UsuarioDTO> obterTodos(){
        List<Usuario> usuarios = usuarioRepository.findAll();
        
        return usuarios.stream()
        .map(usuario -> mapper.map(usuario, UsuarioDTO.class))
        .collect(Collectors.toList());
    }

     /**
     * Método que retorna a usuario encontrada pelo seu Id.
     * @param id da usuario que será localizada
     * @return Retorna uma usuario caso seja encontrado.
     */
    public Optional<UsuarioDTO> obterPorId(Long id){
        Optional<Usuario> usuario = usuarioRepository.findById(id);

        UsuarioDTO usuarioDTO = mapper.map(usuario.get(), UsuarioDTO.class);
        
        return Optional.of(usuarioDTO);
    }

    /**
     * Método para adicionar usuario na lista
     * @param usuario que será adicionada
     * @return Retorna a usuario que será adicionado na lista.
     */
    public UsuarioDTO adicionar(UsuarioDTO usuarioDTO) {    
        usuarioDTO.setId(null);
    
        Usuario usuario = converterDTOParaEntidade(usuarioDTO);
        usuario = usuarioRepository.save(usuario);
        usuarioDTO.setId(usuario.getId());
		
        return usuarioDTO;
    }
    
    public Usuario converterDTOParaEntidade(UsuarioDTO dto) {
    	Usuario usuario = new Usuario();
    	
    	usuario.setLogin(dto.getLogin());
    	usuario.setPassword(dto.getPassword());
//    	usuario.setUltimoLogin(dto.getUltimoLogin());
    	
    	return usuario;
    	
    }

    /*
     * Método para deletar a usuario por id
     * @param id da usuario a ser deletada
     */
    public void deletar(Long id){
        usuarioRepository.deleteById(id);;
    }

    /**
     * Método para atualizar uma usuario da lista
     * @param usuario a ser atualizada
     * @return usuario atualizada
     */
    public UsuarioDTO atualizar(Long id, UsuarioDTO usuarioDTO){
        usuarioDTO.setId(id);

        Usuario usuarioNovo = mapper.map(usuarioDTO, Usuario.class);
        usuarioRepository.save(usuarioNovo);

        return usuarioDTO;
    }

    /**
     * Método para buscar um usuario por sua matrícula
     * @param matricula a ser encontrada
     * @return matricula encontrada
     */
    public Optional<UsuarioDTO> obterPorLogin(String login){
        Optional<Usuario> usuario = usuarioRepository.findByLogin(login);

        UsuarioDTO usuarioDTO = mapper.map(usuario.get(), UsuarioDTO.class);
        return Optional.of(usuarioDTO);
    }
}