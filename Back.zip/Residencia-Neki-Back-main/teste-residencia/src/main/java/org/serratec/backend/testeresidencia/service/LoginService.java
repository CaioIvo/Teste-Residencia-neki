package org.serratec.backend.testeresidencia.service;

import java.util.Optional;

import org.serratec.backend.testeresidencia.domain.Usuario;
import org.serratec.backend.testeresidencia.dto.UsuarioDTO;
import org.serratec.backend.testeresidencia.repository.UsuarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;


@Service
public class LoginService {

	@Autowired
    private UsuarioRepository usuarioRepository;

	@Autowired
    private PasswordEncoder encoder;
    
    public PasswordEncoder getEncoder() {
        return encoder;
    }

    public void setEncoder(PasswordEncoder encoder) {
        this.encoder = encoder;
    }

	/**
	 * Método para obter usuário por matrícula
	 * @param matricula
	 * @return Usuário
	 */
	public Usuario getUsuario(String login) {
		Optional<Usuario> optUsuario = usuarioRepository.findByLogin(login);
		
		if(!optUsuario.isPresent())
			throw new IllegalArgumentException();//usuario nao existe
		
			return optUsuario.get();
	}

	/**
	 * Método para validar a senha do usuário
	 * @param usuarioDTO
	 * @return Senha Válida/Inválida
	 */
	public Boolean validaUsuarioSenha(UsuarioDTO usuarioDTO){    
        Optional<Usuario> login = usuarioRepository.findByLogin(usuarioDTO.getLogin());
       
		if(!login.isPresent()){
            return false;
        }
        
        Usuario uDTO = login.get();
        boolean valid = encoder.matches(usuarioDTO.getPassword(), uDTO.getPassword());

        return valid;
    }
}
