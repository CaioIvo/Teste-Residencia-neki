package org.serratec.backend.testeresidencia.repository;

import java.util.List;

import org.serratec.backend.testeresidencia.domain.UserSkill;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserSkillRepository extends JpaRepository<UserSkill, Long>{
	
	List<UserSkill> findByIdUsuario(Long idUsuario);

}
