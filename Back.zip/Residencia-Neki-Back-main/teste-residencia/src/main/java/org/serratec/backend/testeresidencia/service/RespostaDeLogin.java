package org.serratec.backend.testeresidencia.service;

import org.serratec.backend.testeresidencia.dto.UsuarioResponse;

public class RespostaDeLogin {
	
//#region Atributos
	public String token;
	
	private UsuarioResponse usuarioResponse;	
//#endregion

//#region Atributos
	public String getToken() {
		return token;
	}
	public void setToken(String token) {
		this.token = token;
	}
	public UsuarioResponse getUsuarioResponse() {
		return usuarioResponse;
	}
	public void setUsuarioResponse(UsuarioResponse usuarioResponse) {
		this.usuarioResponse = usuarioResponse;
	}
	public RespostaDeLogin(String token, UsuarioResponse usuarioResponse) {
		this.token = token;
		this.usuarioResponse = usuarioResponse;
	}
//#endregion	
}

