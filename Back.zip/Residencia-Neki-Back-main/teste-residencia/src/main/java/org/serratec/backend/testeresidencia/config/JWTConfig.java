package org.serratec.backend.testeresidencia.config;

import org.serratec.backend.testeresidencia.security.JWTFiltro;
import org.serratec.backend.testeresidencia.service.UsuarioDetalheServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

@Configuration
@EnableWebSecurity
public class JWTConfig extends WebSecurityConfigurerAdapter{
    
    private final UsuarioDetalheServiceImpl usuarioService;
    private final PasswordEncoder passwordEncoder;

    @Autowired
    private JWTFiltro jwtFiltro;

    public JWTConfig(UsuarioDetalheServiceImpl usuarioService, PasswordEncoder passwordEncoder) {
        this.usuarioService = usuarioService;
        this.passwordEncoder = passwordEncoder;
    }

    @Override
    protected void configure(AuthenticationManagerBuilder auth) throws Exception {
        auth.userDetailsService(usuarioService).passwordEncoder(passwordEncoder);
    }
    
    @Override
   	public void configure(WebSecurity web) {
   		web.ignoring().antMatchers("/v2/api-docs",
                                       "/configuration/ui",
                                       "/swagger-resources/**",
                                       "/swagger-ui/**",
                                       "/configuration/security",
                                       "/swagger-ui.html",
                                       "/webjars/**");
    }
     
    @Override
    protected void 	configure(HttpSecurity http) throws Exception {
        http
			.cors().and().csrf().disable()
			.exceptionHandling()
			.and()
			.sessionManagement()
			.sessionCreationPolicy(SessionCreationPolicy.STATELESS)
			.and()
			.authorizeRequests()
			.antMatchers(HttpMethod.POST, "/auth/login")
			.permitAll()
            .antMatchers(HttpMethod.POST, "/usuarios")
			.permitAll()
            .antMatchers("/empresas").permitAll()

		//	.anyRequest().authenticated();  //aqui vc não pode mais fz tudo
            .anyRequest().permitAll();	
			
			http.addFilterBefore(jwtFiltro, UsernamePasswordAuthenticationFilter.class);
    }
}