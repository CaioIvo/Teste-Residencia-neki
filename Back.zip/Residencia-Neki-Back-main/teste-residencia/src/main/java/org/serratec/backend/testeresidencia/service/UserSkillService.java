package org.serratec.backend.testeresidencia.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.serratec.backend.testeresidencia.domain.Skill;
import org.serratec.backend.testeresidencia.domain.UserSkill;
import org.serratec.backend.testeresidencia.dto.ListagemSkillsDTO;
import org.serratec.backend.testeresidencia.dto.UserSkillDTO;
import org.serratec.backend.testeresidencia.repository.SkillRepository;
import org.serratec.backend.testeresidencia.repository.UserSkillRepository;
import org.serratec.backend.testeresidencia.repository.UsuarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserSkillService {
	
	@Autowired
	private UserSkillRepository userSkillRepository;
	
	@Autowired
	private UsuarioRepository usuarioRepository;
	
	@Autowired
	private SkillRepository skillRepository;
	
	@Transactional
	public void associarSkill(UserSkillDTO dto) {
		UserSkill skill = new UserSkill();
		skill = convertDTOParaEntidade(dto);
		userSkillRepository.save(skill);		
	}
	
	public List<UserSkillDTO> listaUserSkill(){
		List<UserSkillDTO> dto = new ArrayList<>();
		List<UserSkill> lista = userSkillRepository.findAll();
		if(lista != null) {
			for (UserSkill userSkill : lista) {
				UserSkillDTO user = new UserSkillDTO();
				user = convertEntidadeParaDTO(userSkill);
				dto.add(user);
			}		
		}
		return dto;
	}
	
	public UserSkillDTO convertEntidadeParaDTO(UserSkill user) {
		UserSkillDTO dto = new UserSkillDTO();
		
		dto.setDataCadastro(user.getDataCadastro());
		dto.setLevel(user.getLevel());
		dto.setUltimaAtualizacao(user.getUltimaAtualizacao());
		dto.setIdUsuario(user.getIdUsuario());
		dto.setIdSkill(user.getIdSkill());
		dto.setId(user.getId());
		
		return dto;
		
	}
	
	public UserSkill convertDTOParaEntidade(UserSkillDTO dto) {
		UserSkill user = new UserSkill();
		
		user.setDataCadastro(dto.getDataCadastro());
		user.setLevel(dto.getLevel());
		user.setUltimaAtualizacao(dto.getUltimaAtualizacao());
		user.setIdUsuario(dto.getIdUsuario());
		user.setIdSkill(dto.getIdSkill());
		
		
		return user;
		
	}
	
	public void atualizarSkill(Long idUserSkill, UserSkillDTO dto) {
		Optional<UserSkill> user = userSkillRepository.findById(idUserSkill);
		if (user.isPresent()) {
			UserSkill userskill = user.get();

			if (dto.getDataCadastro() != null) {
				userskill.setDataCadastro(dto.getDataCadastro());
			}
			if (dto.getLevel() != null) {
				userskill.setLevel(dto.getLevel());
			}
			if (dto.getUltimaAtualizacao() != null) {
				userskill.setUltimaAtualizacao(dto.getUltimaAtualizacao());
			}
			if (dto.getIdUsuario() != null) {
				userskill.setIdUsuario(dto.getIdUsuario());
			}
			if (dto.getIdSkill() != null) {
				userskill.setIdSkill(dto.getIdSkill());
			}
			userSkillRepository.save(userskill);
		}
		
	}
	public void deleteSkill(Long idUserSkill) {
		userSkillRepository.deleteById(idUserSkill);
	}
	
	public ListagemSkillsDTO listaSkillPorUsuario(Long idUsuario) {
		
		ListagemSkillsDTO resultado = new ListagemSkillsDTO();
		
		List<UserSkill> lista = userSkillRepository.findByIdUsuario(idUsuario);
		
		List<Skill> listaSkill = new ArrayList<>();
		
		for (UserSkill userSkill : lista) {
			Skill skill = new Skill();
			skill = skillRepository.findById(userSkill.getIdSkill()).get();
			listaSkill.add(skill);
		}
		
		resultado.setListaSkill(listaSkill);
		resultado.setIdUsuario(idUsuario);
		return resultado;
	}

}
