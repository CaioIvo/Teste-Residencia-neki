package org.serratec.backend.testeresidencia.security;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Optional;

import org.serratec.backend.testeresidencia.dto.UsuarioDTO;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

public class UsuarioDetalhe implements UserDetails {
    
    private static final long serialVersionUID = 1L;

    private final Optional<UsuarioDTO> usuarioDTO;

    public UsuarioDetalhe(Optional<UsuarioDTO> usuarioDTO) {
        this.usuarioDTO = usuarioDTO;
    }

    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
            return new ArrayList<>();
    }

    @Override
    public String getPassword() {
        
        return usuarioDTO.get().getPassword();
    }


    @Override
    public boolean isAccountNonExpired() {
        return true;
    }

    @Override
    public boolean isAccountNonLocked() {
        return true;
    }

    @Override
    public boolean isCredentialsNonExpired() {
        return true;
    }

    @Override
    public boolean isEnabled() {
        return true;
    }

	@Override
	public String getUsername() {
		// TODO Auto-generated method stub
		return null;
	}       
}