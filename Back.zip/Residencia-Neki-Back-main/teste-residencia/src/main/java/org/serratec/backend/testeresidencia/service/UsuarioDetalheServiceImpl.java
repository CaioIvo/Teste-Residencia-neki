package org.serratec.backend.testeresidencia.service;

import java.util.Optional;
import java.util.function.Supplier;

import org.serratec.backend.testeresidencia.domain.Usuario;
import org.serratec.backend.testeresidencia.dto.UsuarioDTO;
import org.serratec.backend.testeresidencia.repository.UsuarioRepository;
import org.serratec.backend.testeresidencia.security.UsuarioDetalhe;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Component;

@Component
public class UsuarioDetalheServiceImpl implements UserDetailsService {

    private final UsuarioService service;

    @Autowired
    private UsuarioRepository usuarioRepository;

    public UsuarioDetalheServiceImpl(UsuarioService service) {
        this.service = service;
    }

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        
        Optional<UsuarioDTO> usuarioDTO = service.obterPorLogin(username);
        if (!usuarioDTO.isPresent()){
            throw new UsernameNotFoundException("Login: "+ username + "não encontrada!");
        }
        return new UsuarioDetalhe(usuarioDTO);
    }

    public UserDetails loadUserById(Long id) {
		
        Usuario usuario = getUser(() -> usuarioRepository.findById(id));
		
        return (UserDetails) usuario;
	}

	private Usuario getUser(Supplier<Optional<Usuario>> supplier) {
		return supplier.get().orElseThrow(() -> new UsernameNotFoundException("Usuário não encontrado"));
	}


    
}
