package org.serratec.backend.testeresidencia.dto;

import java.util.List;

import org.serratec.backend.testeresidencia.domain.Skill;

public class ListagemSkillsDTO {
	
	private List<Skill> listaSkill;
	private Long idUsuario;

	
	public List<Skill> getListaSkill() {
		return listaSkill;
	}
	public void setListaSkill(List<Skill> listaSkill) {
		this.listaSkill = listaSkill;
	}
	public Long getIdUsuario() {
		return idUsuario;
	}
	public void setIdUsuario(Long idUsuario) {
		this.idUsuario = idUsuario;
	}
	
	

}
