package org.serratec.backend.testeresidencia.repository;

import org.serratec.backend.testeresidencia.domain.Usuario;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;

import org.springframework.stereotype.Repository;

@Repository
public interface UsuarioRepository extends JpaRepository<Usuario, Long> { 
    
	
	public Optional<Usuario> findByLogin(String login);
	
}
