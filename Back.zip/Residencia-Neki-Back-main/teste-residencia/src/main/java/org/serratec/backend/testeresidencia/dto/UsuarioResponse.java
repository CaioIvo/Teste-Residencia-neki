package org.serratec.backend.testeresidencia.dto;

public class UsuarioResponse {
 
	private Long id;
	private String login;


	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getLogin() {
		return login;
	}

	public void setLogin(String login) {
		this.login = login;
	}



}
