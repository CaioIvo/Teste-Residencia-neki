package org.serratec.backend.testeresidencia.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.serratec.backend.testeresidencia.domain.Skill;
import org.serratec.backend.testeresidencia.dto.SkillDTO;
import org.serratec.backend.testeresidencia.repository.SkillRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class SkillService {
	
	@Autowired
	private SkillRepository skillRepository;
	
	public void salvar(SkillDTO skillDTO) {
		Skill skill = converterDTOParaEntidade(skillDTO);
		skillRepository.save(skill);
	}
	
	

	public Skill converterDTOParaEntidade(SkillDTO skillDTO) {
		Skill skill = new Skill();
		
		skill.setDescricao(skillDTO.getDescricao());
		skill.setNome(skillDTO.getNome());
		skill.setVersao(skillDTO.getVersao());
		
		return skill;		
	}
	
	public SkillDTO converterEntidadeParaDTO(Skill skill) {
		SkillDTO skillDTO = new SkillDTO();
		
		skillDTO.setDescricao(skill.getDescricao());
		skillDTO.setId(skill.getId());
		skillDTO.setNome(skill.getNome());
		skillDTO.setVersao(skill.getVersao());
		return skillDTO;
	}
	
	public SkillDTO buscarSkillPorId(Long id) {
		Optional<Skill> skill = skillRepository.findById(id);
		SkillDTO skillDTO = new SkillDTO();
		if(skill.isPresent()) {
			Skill s = skill.get();
			skillDTO = converterEntidadeParaDTO(s);
		}
		return skillDTO;
	}
	
	public List<SkillDTO> listaSkill(){
		List<SkillDTO> listaDTO = new ArrayList<>();
		List<Skill> skillLista = skillRepository.findAll();
		if(skillLista != null) {
			for (Skill skill : skillLista) {
				SkillDTO sDTO = new SkillDTO();
				sDTO = converterEntidadeParaDTO(skill);
				listaDTO.add(sDTO);
			}
		}
		return listaDTO;
	}
	
}
