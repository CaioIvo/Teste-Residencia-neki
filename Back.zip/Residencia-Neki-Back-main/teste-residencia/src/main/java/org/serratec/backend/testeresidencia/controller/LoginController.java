package org.serratec.backend.testeresidencia.controller;

import javax.servlet.ServletException;

import org.serratec.backend.testeresidencia.dto.UsuarioDTO;
import org.serratec.backend.testeresidencia.repository.UsuarioRepository;
import org.serratec.backend.testeresidencia.service.JWTService;
import org.serratec.backend.testeresidencia.service.LoginService;
import org.serratec.backend.testeresidencia.service.RespostaDeLogin;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping("/auth")
public class LoginController {

	@Autowired
	private JWTService jwtService;

	@Autowired
	private UsuarioRepository usuarioRepository;

	@Autowired
	private LoginService loginService;
	
	@PostMapping("/login")
	public ResponseEntity<RespostaDeLogin> autentica(@RequestBody UsuarioDTO usuarioDTO) throws ServletException {
		if(!usuarioRepository.findByLogin(usuarioDTO.getLogin()).isPresent()){
			return ResponseEntity.notFound().build();
		}
		if(!loginService.validaUsuarioSenha(usuarioDTO)){
			return ResponseEntity.badRequest().build();
		}
		return new ResponseEntity<RespostaDeLogin>(jwtService.autentica(usuarioDTO), HttpStatus.OK);
	}
}