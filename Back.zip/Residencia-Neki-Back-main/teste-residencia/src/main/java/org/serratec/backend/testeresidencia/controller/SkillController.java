package org.serratec.backend.testeresidencia.controller;

import java.util.List;

import org.serratec.backend.testeresidencia.dto.SkillDTO;
import org.serratec.backend.testeresidencia.service.SkillService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/skill")
public class SkillController {
	
	@Autowired
	private SkillService skillService;
	
	@GetMapping("/{id}")
	public ResponseEntity<SkillDTO> buscarPorId(@PathVariable Long id){
		return ResponseEntity.ok(skillService.buscarSkillPorId(id));
	}
	
	@GetMapping("/lista")
	public ResponseEntity<List<SkillDTO>> listaSkill(){
		return ResponseEntity.ok(skillService.listaSkill());
	}
	
	@PostMapping("/save")
	public ResponseEntity<Void> salvar(@RequestBody SkillDTO skilldto){
		skillService.salvar(skilldto);
		return new ResponseEntity<Void>(HttpStatus.CREATED);
	}

}
