package org.serratec.backend.testeresidencia.repository;

import org.serratec.backend.testeresidencia.domain.Skill;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SkillRepository extends JpaRepository<Skill, Long>{

}
