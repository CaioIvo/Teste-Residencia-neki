package org.serratec.backend.testeresidencia.controller;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import org.modelmapper.ModelMapper;
import org.serratec.backend.testeresidencia.dto.UsuarioDTO;
import org.serratec.backend.testeresidencia.dto.UsuarioRequest;
import org.serratec.backend.testeresidencia.dto.UsuarioResponse;
import org.serratec.backend.testeresidencia.service.UsuarioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@RequestMapping("/usuarios")
public class UsuarioController {

    @Autowired
    private UsuarioService usuarioService;

    @Autowired
	ModelMapper mapper;

    @Autowired
    private PasswordEncoder encoder;
    
    public PasswordEncoder getEncoder() {
        return encoder;
    }

    public void setEncoder(PasswordEncoder encoder) {
        this.encoder = encoder;
    }

     /**
     * Método que retorna uma Lista de usuarios.
     * @return Lista de usuario
     */
    @GetMapping
    public ResponseEntity<List<UsuarioResponse>> obterTodos(){
        List<UsuarioDTO> usuariosDTO = usuarioService.obterTodos();

        List<UsuarioResponse> resposta = usuariosDTO.stream()
        .map(usuarioDTO -> mapper.map(usuarioDTO, UsuarioResponse.class))
        .collect(Collectors.toList());

        return new ResponseEntity<>(resposta, HttpStatus.OK);
    }

     /**
     * Método que retorna a usuario encontrada pelo seu Id.
     * @param id da usuario que será localizada
     * @return Retorna uma usuario caso seja encontrado.
     */
    @GetMapping("/{id}")
    public ResponseEntity<Optional<UsuarioResponse>> obterPorId(@PathVariable Long id){
        Optional<UsuarioDTO> usuarioDTO = usuarioService.obterPorId(id);
        
        UsuarioResponse usuario = new ModelMapper().map(usuarioDTO.get(), UsuarioResponse.class);

        return new ResponseEntity<>(Optional.of(usuario), HttpStatus.OK);
    }   

    /**
     * Método para adicionar usuario na lista
     * @param usuario que será adicionada
     * @return Retorna a usuario que será adicionado na lista.
     */
    @PostMapping
    public ResponseEntity<UsuarioResponse> adicionar(@RequestBody UsuarioRequest usuarioRequest){ 
        usuarioRequest.setPassword(encoder.encode(usuarioRequest.getPassword()));
        UsuarioDTO usuarioDTO = new UsuarioDTO();
        usuarioDTO.setLogin(usuarioRequest.getLogin());
        usuarioDTO.setPassword(usuarioRequest.getPassword());

        usuarioDTO = usuarioService.adicionar(usuarioDTO);

        return new ResponseEntity<>(mapper.map(usuarioDTO, UsuarioResponse.class), HttpStatus.CREATED);
    }

    /**
     * Método para deletar a usuario por id
     * @param id da usuario a ser deletada
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<?> deletar(@PathVariable Long id){
        usuarioService.deletar(id);

        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }

    /**
     * Método para atualizar uma usuario da lista
     * @param usuario a ser atualizada
     * @return usuario atualizada
     */
    @PutMapping("/{id}")
    public ResponseEntity<UsuarioResponse> atualizar(@RequestBody UsuarioRequest usuarioRequest, @PathVariable Long id){
        usuarioRequest.setPassword(encoder.encode(usuarioRequest.getPassword()));
        
        UsuarioDTO usuarioDTO = new UsuarioDTO();
        usuarioDTO.setLogin(usuarioRequest.getLogin());
        usuarioDTO.setPassword(usuarioRequest.getPassword());
        
        usuarioDTO =  usuarioService.atualizar(id, usuarioDTO);
        
        return new ResponseEntity<>(mapper.map(usuarioDTO, UsuarioResponse.class), HttpStatus.OK);
    }
    
    /**
     * Método para validar a matricula e senha do usuário.
     * @param matricula do usuário
     * @param senha do usuário
     * @return
     */
    @GetMapping("/validarsenha")
    public ResponseEntity<Boolean> validarSenha(@RequestParam String loginUser, @RequestParam String senha){   
        Optional<UsuarioDTO> login = usuarioService.obterPorLogin(loginUser);
        
        if(!login.isPresent()){
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(false);
        }
        
        UsuarioDTO uDTO = login.get();
        boolean valid = encoder.matches(senha, uDTO.getPassword());

        HttpStatus status = (valid) ? HttpStatus.OK : HttpStatus.UNAUTHORIZED;
        
        return ResponseEntity.status(status).body(valid);
    }
}