package org.serratec.backend.testeresidencia.exception;

import java.time.LocalDateTime;
import java.util.List;

public class DefaultResponse {

//#region Atributos
	private Integer status;
	private String titulo;
	private LocalDateTime data;
	private List<String> erros; //lista padrão de erros do Spring
//#endregion

//#region Construtor
	public DefaultResponse(Integer status, String titulo, LocalDateTime data, List<String> erros) {
		super();
		this.status = status;
		this.titulo = titulo;
		this.data = data;
		this.erros = erros;
	}
//#endregion

//#region Getters e Setters
	public Integer getStatus() {
		return status;
	}
	public void setStatus(Integer status) {
		this.status = status;
	}
	public String getTitulo() {
		return titulo;
	}
	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}
	public LocalDateTime getData() {
		return data;
	}
	public void setData(LocalDateTime data) {
		this.data = data;
	}
	public List<String> getErros() {
		return erros;
	}
	public void setErros(List<String> erros) {
		this.erros = erros;
	}
//#endregion	
}
