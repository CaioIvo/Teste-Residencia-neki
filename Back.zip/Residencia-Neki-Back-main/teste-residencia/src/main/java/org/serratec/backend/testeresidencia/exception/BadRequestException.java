package org.serratec.backend.testeresidencia.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(code = HttpStatus.BAD_REQUEST)
public class BadRequestException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7590943001708306693L;

	public BadRequestException() {
		super("Recurso fora dos parâmetros da API");
	}

	public BadRequestException(String mensagem) {
		super(mensagem);
	}
}
