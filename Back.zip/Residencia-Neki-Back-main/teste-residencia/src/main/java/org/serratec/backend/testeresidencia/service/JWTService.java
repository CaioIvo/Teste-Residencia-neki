package org.serratec.backend.testeresidencia.service;

import java.util.Date;
import java.util.Optional;
import org.modelmapper.ModelMapper;
import org.serratec.backend.testeresidencia.dto.UsuarioDTO;
import org.serratec.backend.testeresidencia.dto.UsuarioResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jws;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.SignatureException;

@Service
public class JWTService {

	@Autowired
	ModelMapper mapper;

	@Autowired
	private UsuarioService usuarioService;
	
	public LoginService loginService;
	
	@Autowired
	public JWTService(@Lazy LoginService loginService) {
		this.loginService = loginService;
	}

	public static final String TOKEN_KEY = "6fd73a86-f249-4154-a33d-508e4ef1f600";
	public final static int TOKEN_INDEX = 7;

	/**
	 * Método para autenticar o usuário no login
	 * @param usuarioDTO
	 * @return
	 */
	public RespostaDeLogin autentica(UsuarioDTO usuarioDTO) {
		usuarioDTO = usuarioService.obterPorLogin(usuarioDTO.getLogin()).get();

        UsuarioResponse usuarioResponse = mapper.map(usuarioDTO, UsuarioResponse.class);

		// if (!loginService.validaUsuarioSenha(usuarioDTO)) {
		// 	return new RespostaDeLogin("UsuarioDTO ou senha invalidos. Nao foi realizado o login.", usuarioResponse);
		// }

		String token = geraToken(usuarioDTO.getLogin());

		return new RespostaDeLogin(token, usuarioResponse);
	}

	/**
	 * Método para gerar o Token
	 * @param matricula
	 * @return
	 */
	public String geraToken(String matricula) {
		return Jwts.builder().setHeaderParam("typ", "JWT").setSubject(matricula)
				.signWith(SignatureAlgorithm.HS512, TOKEN_KEY)
				.setExpiration(new Date(System.currentTimeMillis() + 300 * 60 * 1000)).compact();//Tempo que "dura" a autenticação
	}

	/**
	 * Método para conseguir o Sujeito da autenticação
	 * @param authorizationHeader
	 * @return Subject
	 */
	public String getSujeitoDoToken(String authorizationHeader) {
		if (authorizationHeader == null || !authorizationHeader.startsWith("Bearer ")) {
			throw new SecurityException("Token inexistente ou mal formatado!");
		}

		// Extraindo apenas o token do cabecalho.
		String token = authorizationHeader.substring(TOKEN_INDEX);

		String subject = null;
		try {
			subject = Jwts.parser().setSigningKey(TOKEN_KEY).parseClaimsJws(token).getBody().getSubject();
		} catch (SignatureException e) {
			throw new SecurityException("Token invalido ou expirado!");
		}
		return subject;
	}

	/**
	 * Método para retornar o usuário por seu token.
	 * @param token
	 * @return Usuário
	 */
	public Optional<String> obterMatriculaDoUsuario(String token){
		try {
			Claims claims = parse(token).getBody();
			return Optional.ofNullable(claims.getSubject());	
		} catch (Exception e) {
			return Optional.empty();
		}
	}

	private Jws<Claims> parse(String token){
		return Jwts.parser().setSigningKey(TOKEN_KEY).parseClaimsJws(token);
	}
}
